<?php $__env->startSection('content'); ?>
<div class="mb-6">
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-2xl font-bold text-gray-900">Tambah Visi, Misi & Nilai Dasar</h1>
            <p class="text-gray-600">Tambahkan visi, misi, dan nilai dasar baru untuk desa</p>
        </div>
         <a href="<?php echo e(route('admin.visi-misi.index')); ?>" class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg font-medium flex items-center">
        <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z" clip-rule="evenodd"></path>
        </svg>
        Kembali
    </a>
    </div>
</div>

<!-- Error Messages -->
<?php if($errors->any()): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
        <ul class="list-disc list-inside">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<form action="<?php echo e(route('admin.visi-misi.store')); ?>" method="POST" class="space-y-6">
    <?php echo csrf_field(); ?>

    <div class="bg-white rounded-lg shadow p-6">
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <!-- Periode -->
            <div class="lg:col-span-2">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Periode</h3>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label for="periode_awal" class="block text-sm font-medium text-gray-700 mb-2">Tahun Awal</label>
                        <input type="text" name="periode_awal" id="periode_awal"
                               class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                               placeholder="2024" value="<?php echo e(old('periode_awal')); ?>" maxlength="4" required>
                    </div>
                    <div>
                        <label for="periode_akhir" class="block text-sm font-medium text-gray-700 mb-2">Tahun Akhir</label>
                        <input type="text" name="periode_akhir" id="periode_akhir"
                               class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                               placeholder="2030" value="<?php echo e(old('periode_akhir')); ?>" maxlength="4" required>
                    </div>
                </div>
            </div>

            <!-- Visi -->
            <div class="lg:col-span-2">
                <label for="visi" class="block text-sm font-medium text-gray-700 mb-2">Visi</label>
                <textarea name="visi" id="visi" rows="4"
                          class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          placeholder="Masukkan visi desa..." required><?php echo e(old('visi')); ?></textarea>
                <p class="mt-1 text-sm text-gray-500">Tuliskan visi desa dengan jelas dan inspiratif</p>
            </div>

            <!-- Misi -->
            <div class="lg:col-span-2">
                <label for="misi" class="block text-sm font-medium text-gray-700 mb-2">Misi</label>
                <textarea name="misi" id="misi" rows="8"
                          class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          placeholder="1. Misi pertama&#10;2. Misi kedua&#10;3. Misi ketiga" required><?php echo e(old('misi')); ?></textarea>
                <p class="mt-1 text-sm text-gray-500">Tuliskan setiap misi dalam baris baru (Enter untuk baris baru)</p>
            </div>

            <!-- Nilai Dasar -->
            <div class="lg:col-span-2">
                <label for="nilai_dasar" class="block text-sm font-medium text-gray-700 mb-2">Nilai Dasar</label>
                <textarea name="nilai_dasar" id="nilai_dasar" rows="6"
                          class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          placeholder="1. Nilai dasar pertama&#10;2. Nilai dasar kedua&#10;3. Nilai dasar ketiga"><?php echo e(old('nilai_dasar')); ?></textarea>
                <p class="mt-1 text-sm text-gray-500">Nilai-nilai dasar yang dipegang teguh oleh desa (opsional)</p>
            </div>

            <!-- Tujuan -->
            <div>
                <label for="tujuan" class="block text-sm font-medium text-gray-700 mb-2">Tujuan</label>
                <textarea name="tujuan" id="tujuan" rows="6"
                          class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          placeholder="1. Tujuan pertama&#10;2. Tujuan kedua"><?php echo e(old('tujuan')); ?></textarea>
                <p class="mt-1 text-sm text-gray-500">Tujuan yang ingin dicapai (opsional)</p>
            </div>

            <!-- Sasaran -->
            <div>
                <label for="sasaran" class="block text-sm font-medium text-gray-700 mb-2">Sasaran</label>
                <textarea name="sasaran" id="sasaran" rows="6"
                          class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          placeholder="1. Sasaran pertama&#10;2. Sasaran kedua"><?php echo e(old('sasaran')); ?></textarea>
                <p class="mt-1 text-sm text-gray-500">Sasaran yang ditargetkan (opsional)</p>
            </div>

            <!-- Status -->
            <div class="lg:col-span-2">
                <div class="flex items-center">
                    <input type="checkbox" name="is_active" id="is_active" value="1"
                           class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                           <?php echo e(old('is_active') ? 'checked' : ''); ?>>
                    <label for="is_active" class="ml-2 block text-sm text-gray-900">
                        Aktifkan sebagai visi misi utama
                    </label>
                </div>
                <p class="mt-1 text-sm text-gray-500">Jika dicentang, visi misi ini akan menjadi yang aktif dan menggantikan yang lama</p>
            </div>
        </div>
    </div>

    <!-- Action Buttons -->
    <div class="flex justify-end space-x-3">
        <a href="<?php echo e(route('admin.visi-misi.index')); ?>"
           class="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
            Batal
        </a>
        <button type="submit"
                class="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
            <svg class="w-4 h-4 inline mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
            </svg>
            Simpan
        </button>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/viper/Music/desa-tanjung-selamat/resources/views/admin/visi-misi/create.blade.php ENDPATH**/ ?>