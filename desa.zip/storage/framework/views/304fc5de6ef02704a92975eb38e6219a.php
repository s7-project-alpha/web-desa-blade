<?php $__env->startSection('content'); ?>
<div class="mb-6 flex items-center justify-between">
    <div >
        <h1 class="text-2xl font-bold text-gray-900">Edit Kategori Galeri</h1>
    <p class="text-gray-600">Ubah informasi kategori galeri</p>
    </div>


     <a href="<?php echo e(route('admin.kategori-galeri.index')); ?>" class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg font-medium flex items-center">
        <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z" clip-rule="evenodd"></path>
        </svg>
        Kembali
    </a>
</div>

<div class="bg-white rounded-lg shadow">
    <form action="<?php echo e(route('admin.kategori-galeri.update', $kategoriGaleri)); ?>" method="POST" class="p-6">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <!-- Left Column -->
            <div class="space-y-6">
                <!-- Nama Kategori -->
                <div>
                    <label for="nama_kategori" class="block text-sm font-medium text-gray-700 mb-2">
                        Nama Kategori *
                    </label>
                    <input type="text"
                           id="nama_kategori"
                           name="nama_kategori"
                           value="<?php echo e(old('nama_kategori', $kategoriGaleri->nama_kategori)); ?>"
                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent <?php $__errorArgs = ['nama_kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           placeholder="Contoh: Kegiatan Desa"
                           required>
                    <?php $__errorArgs = ['nama_kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Slug -->
                <div>
                    <label for="slug" class="block text-sm font-medium text-gray-700 mb-2">
                        Slug
                        <span class="text-gray-500 text-xs">(Opsional, akan otomatis dibuat jika kosong)</span>
                    </label>
                    <input type="text"
                           id="slug"
                           name="slug"
                           value="<?php echo e(old('slug', $kategoriGaleri->slug)); ?>"
                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           placeholder="kegiatan-desa">
                    <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Deskripsi -->
                <div>
                    <label for="deskripsi" class="block text-sm font-medium text-gray-700 mb-2">
                        Deskripsi
                    </label>
                    <textarea id="deskripsi"
                              name="deskripsi"
                              rows="4"
                              class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                              placeholder="Deskripsi kategori galeri..."><?php echo e(old('deskripsi', $kategoriGaleri->deskripsi)); ?></textarea>
                    <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <!-- Right Column -->
            <div class="space-y-6">
                <!-- Warna Badge -->
                <div>
                    <label for="warna_badge" class="block text-sm font-medium text-gray-700 mb-2">
                        Warna Badge *
                    </label>
                    <div class="flex items-center space-x-3">
                        <input type="color"
                               id="warna_badge"
                               name="warna_badge"
                               value="<?php echo e(old('warna_badge', $kategoriGaleri->warna_badge)); ?>"
                               class="w-16 h-10 border border-gray-300 rounded-md cursor-pointer <?php $__errorArgs = ['warna_badge'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <div class="flex-1">
                            <input type="text"
                                   id="warna_badge_text"
                                   value="<?php echo e(old('warna_badge', $kategoriGaleri->warna_badge)); ?>"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                   placeholder="#3B82F6"
                                   readonly>
                        </div>
                    </div>
                    <?php $__errorArgs = ['warna_badge'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Urutan -->
                <div>
                    <label for="urutan" class="block text-sm font-medium text-gray-700 mb-2">
                        Urutan *
                    </label>
                    <input type="number"
                           id="urutan"
                           name="urutan"
                           value="<?php echo e(old('urutan', $kategoriGaleri->urutan)); ?>"
                           min="0"
                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent <?php $__errorArgs = ['urutan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           required>
                    <p class="mt-1 text-sm text-gray-500">Urutan tampil kategori (angka kecil tampil duluan)</p>
                    <?php $__errorArgs = ['urutan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Status Aktif -->
                <div>
                    <label class="flex items-center">
                        <input type="checkbox"
                               id="is_active"
                               name="is_active"
                               value="1"
                               <?php echo e(old('is_active', $kategoriGaleri->is_active) ? 'checked' : ''); ?>

                               class="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                        <span class="ml-2 text-sm text-gray-700">Kategori aktif</span>
                    </label>
                    <p class="mt-1 text-sm text-gray-500">Kategori yang tidak aktif tidak akan tampil di website publik</p>
                </div>

                <!-- Preview Badge -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Preview Badge
                    </label>
                    <div class="border border-gray-200 rounded-md p-4 bg-gray-50">
                        <span id="badge_preview" class="inline-block px-3 py-1 rounded-full text-xs font-medium text-white" style="background-color: <?php echo e($kategoriGaleri->warna_badge); ?>;">
                            <?php echo e($kategoriGaleri->nama_kategori); ?>

                        </span>
                    </div>
                </div>

                <!-- Current Stats -->
                <div class="p-4 bg-blue-50 rounded-lg">
                    <h4 class="text-sm font-medium text-gray-900 mb-2">Statistik Saat Ini</h4>
                    <div class="grid grid-cols-2 gap-4 text-sm">
                        <div>
                            <span class="text-gray-500">Total Galeri:</span>
                            <span class="font-medium text-blue-600"><?php echo e($kategoriGaleri->galeri->count()); ?></span>
                        </div>
                        <div>
                            <span class="text-gray-500">Galeri Aktif:</span>
                            <span class="font-medium text-green-600"><?php echo e($kategoriGaleri->galeri->where('is_active', true)->count()); ?></span>
                        </div>
                        <div>
                            <span class="text-gray-500">Dibuat:</span>
                            <span class="font-medium"><?php echo e($kategoriGaleri->created_at->format('d M Y')); ?></span>
                        </div>
                        <div>
                            <span class="text-gray-500">Diupdate:</span>
                            <span class="font-medium"><?php echo e($kategoriGaleri->updated_at->format('d M Y')); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="flex justify-between items-center mt-8 pt-6 border-t border-gray-200">
            <div class="flex space-x-3">
                <a href="<?php echo e(route('admin.kategori-galeri.show', $kategoriGaleri)); ?>" class="text-blue-600 hover:text-blue-800 font-medium">
                    ← Lihat Detail
                </a>
                <a href="<?php echo e(route('public.galeri.index', ['kategori' => $kategoriGaleri->slug])); ?>" target="_blank" class="text-green-600 hover:text-green-800 font-medium">
                    Lihat di Website →
                </a>
            </div>

            <div class="flex space-x-3">
                <a href="<?php echo e(route('admin.kategori-galeri.index')); ?>" class="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 transition duration-200">
                    Batal
                </a>
                <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition duration-200">
                    Update Kategori
                </button>
            </div>
        </div>
    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const namaKategoriInput = document.getElementById('nama_kategori');
    const slugInput = document.getElementById('slug');
    const warnaBadgeInput = document.getElementById('warna_badge');
    const warnaBadgeTextInput = document.getElementById('warna_badge_text');
    const badgePreview = document.getElementById('badge_preview');

    // Auto generate slug from nama kategori (only if not manually edited)
    namaKategoriInput.addEventListener('input', function() {
        if (!slugInput.dataset.manual) {
            const slug = this.value
                .toLowerCase()
                .replace(/[^a-z0-9\s-]/g, '')
                .replace(/\s+/g, '-')
                .replace(/-+/g, '-')
                .trim('-');
            slugInput.value = slug;
        }

        // Update badge preview text
        badgePreview.textContent = this.value || 'Preview Kategori';
    });

    // Mark slug as manually edited
    slugInput.addEventListener('input', function() {
        slugInput.dataset.manual = 'true';
    });

    // Update color preview
    warnaBadgeInput.addEventListener('input', function() {
        warnaBadgeTextInput.value = this.value;
        badgePreview.style.backgroundColor = this.value;
    });

    warnaBadgeTextInput.addEventListener('input', function() {
        if (/^#[0-9A-F]{6}$/i.test(this.value)) {
            warnaBadgeInput.value = this.value;
            badgePreview.style.backgroundColor = this.value;
        }
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/viper/Music/desa-tanjung-selamat/resources/views/admin/kategori-galeri/edit.blade.php ENDPATH**/ ?>