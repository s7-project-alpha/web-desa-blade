<?php $__env->startSection('content'); ?>
<div class="mb-6">
    <div class="flex items-center space-x-4 justify-between">
       <div>
            <h1 class="text-3xl font-bold text-gray-900">
                <?php echo e(isset($kategoriBerita) ? 'Edit Kategori Berita' : 'Tambah Kategori Berita'); ?>

            </h1>
            <p class="text-gray-600 mt-2">
                <?php echo e(isset($kategoriBerita) ? 'Perbarui informasi kategori berita' : 'Buat kategori baru untuk mengorganisir berita'); ?>

            </p>
        </div>
         <a href="<?php echo e(route('admin.berita.index')); ?>" class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg font-medium flex items-center">
        <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z" clip-rule="evenodd"></path>
        </svg>
        Kembali
    </a>
    </div>
</div>

<div class="glass-card rounded-2xl shadow-xl p-8">
    <form action="<?php echo e(isset($kategoriBerita) ? route('admin.kategori-berita.update', $kategoriBerita) : route('admin.kategori-berita.store')); ?>"
          method="POST" class="space-y-6">
        <?php echo csrf_field(); ?>
        <?php if(isset($kategoriBerita)): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <!-- Nama Kategori -->
            <div class="lg:col-span-1">
                <label for="nama" class="block text-sm font-semibold text-gray-700 mb-2">
                    Nama Kategori <span class="text-red-500">*</span>
                </label>
                <input type="text"
                       id="nama"
                       name="nama"
                       value="<?php echo e(old('nama', $kategoriBerita->nama ?? '')); ?>"
                       class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       placeholder="Masukkan nama kategori"
                       required>
                <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Slug -->
            <div class="lg:col-span-1">
                <label for="slug" class="block text-sm font-semibold text-gray-700 mb-2">
                    Slug
                    <span class="text-gray-500 text-xs font-normal">(Otomatis dihasilkan jika kosong)</span>
                </label>
                <input type="text"
                       id="slug"
                       name="slug"
                       value="<?php echo e(old('slug', $kategoriBerita->slug ?? '')); ?>"
                       class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       placeholder="kategori-slug">
                <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <!-- Deskripsi -->
        <div>
            <label for="deskripsi" class="block text-sm font-semibold text-gray-700 mb-2">
                Deskripsi
            </label>
            <textarea id="deskripsi"
                      name="deskripsi"
                      rows="3"
                      class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                      placeholder="Deskripsi singkat tentang kategori ini"><?php echo e(old('deskripsi', $kategoriBerita->deskripsi ?? '')); ?></textarea>
            <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <!-- Warna -->
            <div>
                <label for="warna" class="block text-sm font-semibold text-gray-700 mb-2">
                    Warna Kategori <span class="text-red-500">*</span>
                </label>
                <div class="flex items-center space-x-3">
                    <input type="color"
                           id="warna"
                           name="warna"
                           value="<?php echo e(old('warna', $kategoriBerita->warna ?? '#3B82F6')); ?>"
                           class="w-12 h-12 border-2 border-gray-300 rounded-lg cursor-pointer <?php $__errorArgs = ['warna'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <input type="text"
                           id="warna_text"
                           value="<?php echo e(old('warna', $kategoriBerita->warna ?? '#3B82F6')); ?>"
                           class="flex-1 px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 font-mono text-sm"
                           placeholder="#3B82F6"
                           readonly>
                </div>
                <?php $__errorArgs = ['warna'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Icon -->
            <div>
                <label for="icon" class="block text-sm font-semibold text-gray-700 mb-2">
                    Icon CSS Class
                    <span class="text-gray-500 text-xs font-normal">(Opsional)</span>
                </label>
                <input type="text"
                       id="icon"
                       name="icon"
                       value="<?php echo e(old('icon', $kategoriBerita->icon ?? '')); ?>"
                       class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 <?php $__errorArgs = ['icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       placeholder="fas fa-newspaper">
                <?php $__errorArgs = ['icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Urutan -->
            <div>
                <label for="urutan" class="block text-sm font-semibold text-gray-700 mb-2">
                    Urutan
                </label>
                <input type="number"
                       id="urutan"
                       name="urutan"
                       value="<?php echo e(old('urutan', $kategoriBerita->urutan ?? 0)); ?>"
                       min="0"
                       class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 <?php $__errorArgs = ['urutan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       placeholder="0">
                <?php $__errorArgs = ['urutan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <!-- Preview -->
        <div class="bg-gray-50 rounded-xl p-6">
            <h3 class="text-sm font-semibold text-gray-700 mb-4">Preview Kategori</h3>
            <div id="preview" class="flex items-center space-x-3 p-4 bg-white rounded-lg border">
                <div id="preview-icon" class="w-10 h-10 rounded-xl flex items-center justify-center text-white" style="background-color: <?php echo e(old('warna', $kategoriBerita->warna ?? '#3B82F6')); ?>;">
                    <?php if(old('icon', $kategoriBerita->icon ?? '')): ?>
                        <i class="<?php echo e(old('icon', $kategoriBerita->icon ?? '')); ?>"></i>
                    <?php else: ?>
                        <div class="w-4 h-4 rounded-full bg-white"></div>
                    <?php endif; ?>
                </div>
                <div>
                    <div id="preview-nama" class="font-medium text-gray-900">
                        <?php echo e(old('nama', $kategoriBerita->nama ?? 'Nama Kategori')); ?>

                    </div>
                    <div id="preview-deskripsi" class="text-sm text-gray-500">
                        <?php echo e(old('deskripsi', $kategoriBerita->deskripsi ?? 'Deskripsi kategori akan muncul di sini')); ?>

                    </div>
                </div>
            </div>
        </div>

        <!-- Actions -->
        <div class="flex items-center justify-end space-x-4 pt-6">
            <a href="<?php echo e(route('admin.kategori-berita.index')); ?>"
               class="px-6 py-3 border border-gray-300 text-gray-700 font-medium rounded-xl hover:bg-gray-50 transition-colors duration-200">
                Batal
            </a>
            <button type="submit"
                    class="btn-modern px-8 py-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white font-semibold rounded-xl hover:from-blue-700 hover:to-blue-800 transition-all duration-200 shadow-lg hover:shadow-xl">
                <?php echo e(isset($kategoriBerita) ? 'Perbarui' : 'Simpan'); ?> Kategori
            </button>
        </div>
    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const namaInput = document.getElementById('nama');
    const slugInput = document.getElementById('slug');
    const deskripsiInput = document.getElementById('deskripsi');
    const warnaInput = document.getElementById('warna');
    const warnaTextInput = document.getElementById('warna_text');
    const iconInput = document.getElementById('icon');

    const previewNama = document.getElementById('preview-nama');
    const previewDeskripsi = document.getElementById('preview-deskripsi');
    const previewIcon = document.getElementById('preview-icon');

    // Auto generate slug
    namaInput.addEventListener('input', function() {
        if (!slugInput.value || slugInput.dataset.autoGenerated) {
            const slug = this.value.toLowerCase()
                .replace(/[^a-z0-9\s-]/g, '')
                .replace(/\s+/g, '-')
                .replace(/-+/g, '-')
                .trim('-');
            slugInput.value = slug;
            slugInput.dataset.autoGenerated = 'true';
        }
        previewNama.textContent = this.value || 'Nama Kategori';
    });

    // Manual slug edit
    slugInput.addEventListener('input', function() {
        if (this.value) {
            slugInput.dataset.autoGenerated = 'false';
        }
    });

    // Update preview description
    deskripsiInput.addEventListener('input', function() {
        previewDeskripsi.textContent = this.value || 'Deskripsi kategori akan muncul di sini';
    });

    // Color picker sync
    warnaInput.addEventListener('input', function() {
        warnaTextInput.value = this.value;
        previewIcon.style.backgroundColor = this.value;
    });

    // Icon preview
    iconInput.addEventListener('input', function() {
        const iconElement = previewIcon.querySelector('i, div');
        if (this.value) {
            previewIcon.innerHTML = `<i class="${this.value}"></i>`;
        } else {
            previewIcon.innerHTML = '<div class="w-4 h-4 rounded-full bg-white"></div>';
        }
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/viper/Music/desa-tanjung-selamat/resources/views/admin/kategori-berita/form.blade.php ENDPATH**/ ?>