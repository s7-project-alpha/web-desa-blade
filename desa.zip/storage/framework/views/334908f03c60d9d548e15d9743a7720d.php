<?php $__env->startSection('title', $berita->judul . ' - Desa Tanjung Selamat'); ?>
<?php $__env->startSection('description', $berita->ringkasan); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
    <!-- Breadcrumb -->
    <nav class="flex mb-8" aria-label="Breadcrumb">
        <ol class="inline-flex items-center space-x-1 md:space-x-3">
            <li class="inline-flex items-center">
                <a href="<?php echo e(route('public.home')); ?>" class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600">
                    <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M10.707 2.293a1 1 0 00-1.414 0l-9 9a1 1 0 001.414 1.414L2 12.414V15a3 3 0 003 3h6a3 3 0 003-3v-2.586l.293.293a1 1 0 001.414-1.414l-9-9z"></path>
                    </svg>
                    Beranda
                </a>
            </li>
            <li>
                <div class="flex items-center">
                    <svg class="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                    </svg>
                    <a href="<?php echo e(route('public.berita')); ?>" class="ml-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ml-2">Berita</a>
                </div>
            </li>
            <li>
                <div class="flex items-center">
                    <svg class="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                    </svg>
                    <span class="ml-1 text-sm font-medium text-gray-500 md:ml-2"><?php echo e(Str::limit($berita->judul, 50)); ?></span>
                </div>
            </li>
        </ol>
    </nav>

    <div class="lg:grid lg:grid-cols-4 lg:gap-8">
        <!-- Main Content -->
        <div class="lg:col-span-3">
            <article class="bg-white rounded-xl shadow-lg overflow-hidden">
                <!-- Article Header -->
                <div class="p-8">
                    <!-- Meta Info -->
                    <div class="flex items-center space-x-4 mb-6">
                        <?php if($berita->jenis === 'pengumuman'): ?>
                            <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-orange-100 text-orange-800">
                                📢 Pengumuman
                            </span>
                        <?php endif; ?>
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium"
                              style="background-color: <?php echo e($berita->kategori->warna); ?>20; color: <?php echo e($berita->kategori->warna); ?>;">
                            <?php echo e($berita->kategori->nama); ?>

                        </span>
                        <?php if($berita->is_featured): ?>
                            <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-yellow-100 text-yellow-800">
                                ⭐ Berita Utama
                            </span>
                        <?php endif; ?>
                        <?php if($berita->is_urgent): ?>
                            <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-red-100 text-red-800">
                                🚨 Penting
                            </span>
                        <?php endif; ?>
                    </div>

                    <!-- Title -->
                    <h1 class="text-3xl lg:text-4xl font-bold text-gray-900 mb-6"><?php echo e($berita->judul); ?></h1>

                    <!-- Article Info -->
                    <div class="flex flex-wrap items-center gap-6 text-sm text-gray-600 mb-8 pb-8 border-b border-gray-200">
                        <div class="flex items-center">
                            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd"></path>
                            </svg>
                            <span>oleh <strong><?php echo e($berita->author_name); ?></strong></span>
                        </div>
                        <div class="flex items-center">
                            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd"></path>
                            </svg>
                            <span><?php echo e($berita->formatted_date); ?></span>
                        </div>
                        <div class="flex items-center">
                            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                <path d="M10 12a2 2 0 100-4 2 2 0 000 4z"></path>
                                <path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"></path>
                            </svg>
                            <span><?php echo e($berita->views); ?> views</span>
                        </div>
                        <div class="flex items-center">
                            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clip-rule="evenodd"></path>
                            </svg>
                            <span><?php echo e($berita->reading_time); ?></span>
                        </div>
                    </div>

                    <!-- Summary -->
                    <div class="bg-blue-50 border-l-4 border-blue-400 p-6 mb-8">
                        <p class="text-lg text-gray-800 leading-relaxed"><?php echo e($berita->ringkasan); ?></p>
                    </div>
                </div>

                <!-- Featured Image -->
                <?php if($berita->gambar_utama): ?>
                    <div class="px-8 mb-8">
                        <img src="<?php echo e($berita->getGambarUtamaUrl()); ?>"
                             alt="<?php echo e($berita->judul); ?>"
                             class="w-full h-96 object-cover rounded-xl shadow-lg">
                    </div>
                <?php endif; ?>

                <!-- Article Content -->
                <div class="px-8 pb-8">
                    <div class="prose prose-lg max-w-none">
                        <?php echo nl2br(e($berita->konten)); ?>

                    </div>

                    <!-- Tags -->
                    <?php if($berita->tags && count($berita->tags) > 0): ?>
                        <div class="mt-12 pt-8 border-t border-gray-200">
                            <h3 class="text-sm font-medium text-gray-700 mb-4">Tags:</h3>
                            <div class="flex flex-wrap gap-2">
                                <?php $__currentLoopData = $berita->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="inline-flex items-center px-3 py-1 rounded-full text-sm bg-gray-100 text-gray-700 hover:bg-gray-200 transition-colors duration-200">
                                        #<?php echo e($tag); ?>

                                    </span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- Source -->
                    <?php if($berita->sumber): ?>
                        <div class="mt-8 pt-6 border-t border-gray-200">
                            <p class="text-sm text-gray-600">
                                <strong>Sumber:</strong> <?php echo e($berita->sumber); ?>

                            </p>
                        </div>
                    <?php endif; ?>

                    <!-- Share Buttons -->
                    
                </div>
            </article>

            <!-- Related Articles -->
            <?php if($beritaTerkait->count() > 0): ?>
                <section class="mt-12">
                    <h2 class="text-2xl font-bold text-gray-900 mb-8">Berita Terkait</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <?php $__currentLoopData = $beritaTerkait; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $terkait): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <article class="bg-white rounded-xl shadow-md overflow-hidden group hover:shadow-lg transition-shadow duration-200">
                                <img src="<?php echo e($terkait->getGambarUtamaUrl()); ?>"
                                     alt="<?php echo e($terkait->judul); ?>"
                                     class="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-200">
                                <div class="p-6">
                                    <div class="flex items-center space-x-2 mb-3">
                                        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium"
                                              style="background-color: <?php echo e($terkait->kategori->warna); ?>20; color: <?php echo e($terkait->kategori->warna); ?>;">
                                            <?php echo e($terkait->kategori->nama); ?>

                                        </span>
                                        <span class="text-xs text-gray-500"><?php echo e($terkait->formatted_date); ?></span>
                                    </div>
                                    <h3 class="text-lg font-bold text-gray-900 mb-3 group-hover:text-blue-600 transition-colors duration-200">
                                        <a href="<?php echo e(route('public.berita.detail', $terkait->slug)); ?>">
                                            <?php echo e($terkait->judul); ?>

                                        </a>
                                    </h3>
                                    <p class="text-gray-600 mb-4 line-clamp-2"><?php echo e($terkait->ringkasan); ?></p>
                                    <a href="<?php echo e(route('public.berita.detail', $terkait->slug)); ?>"
                                       class="inline-flex items-center text-blue-600 hover:text-blue-800 font-medium text-sm">
                                        Baca Selengkapnya
                                        <svg class="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                                        </svg>
                                    </a>
                                </div>
                            </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </section>
            <?php endif; ?>
        </div>

        <!-- Sidebar -->
        <div class="lg:col-span-1 mt-12 lg:mt-0">
            <!-- Latest News -->
            <div class="bg-white rounded-xl shadow-md p-6 mb-8">
                <h3 class="text-lg font-semibold text-gray-900 mb-6">Berita Terbaru</h3>
                <div class="space-y-6">
                    <?php $__currentLoopData = $beritaTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="flex space-x-3">
                            <img src="<?php echo e($item->getGambarUtamaUrl()); ?>"
                                 alt="<?php echo e($item->judul); ?>"
                                 class="w-16 h-16 object-cover rounded-lg flex-shrink-0">
                            <div class="flex-1">
                                <h4 class="text-sm font-medium text-gray-900 line-clamp-2 mb-2">
                                    <a href="<?php echo e(route('public.berita.detail', $item->slug)); ?>" class="hover:text-blue-600">
                                        <?php echo e($item->judul); ?>

                                    </a>
                                </h4>
                                <p class="text-xs text-gray-500"><?php echo e($item->formatted_date); ?></p>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- Popular News -->
            <?php if($beritaPopuler->count() > 0): ?>
                <div class="bg-white rounded-xl shadow-md p-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-6">Berita Populer</h3>
                    <div class="space-y-4">
                        <?php $__currentLoopData = $beritaPopuler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $populer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <article class="flex items-start space-x-3">
                                <div class="flex-shrink-0 w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-sm font-bold">
                                    <?php echo e($index + 1); ?>

                                </div>
                                <div class="flex-1">
                                    <h4 class="text-sm font-medium text-gray-900 line-clamp-2 mb-1">
                                        <a href="<?php echo e(route('public.berita.detail', $populer->slug)); ?>" class="hover:text-blue-600">
                                            <?php echo e($populer->judul); ?>

                                        </a>
                                    </h4>
                                    <div class="flex items-center text-xs text-gray-500 space-x-2">
                                        <span><?php echo e($populer->views); ?> views</span>
                                        <span>•</span>
                                        <span><?php echo e($populer->formatted_date); ?></span>
                                    </div>
                                </div>
                            </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('public.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/viper/Music/desa-tanjung-selamat/resources/views/public/berita/detail.blade.php ENDPATH**/ ?>