<?php $__env->startSection('content'); ?>
<div class="mb-6">
    <div class="flex items-center space-x-4 justify-between">
       <div>
            <h1 class="text-3xl font-bold text-gray-900">
                <?php echo e(isset($berita) ? 'Edit Berita' : 'Tulis Berita Baru'); ?>

            </h1>
            <p class="text-gray-600 mt-2">
                <?php echo e(isset($berita) ? 'Perbarui informasi berita' : 'Buat berita atau pengumuman baru'); ?>

            </p>
        </div>
        <a href="<?php echo e(route('admin.berita.index')); ?>" class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg font-medium flex items-center">
        <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z" clip-rule="evenodd"></path>
        </svg>
        Kembali
    </a>
    </div>
</div>

<form action="<?php echo e(isset($berita) ? route('admin.berita.update', $berita) : route('admin.berita.store')); ?>"
      method="POST"
      enctype="multipart/form-data"
      class="grid grid-cols-1 lg:grid-cols-3 gap-8">
    <?php echo csrf_field(); ?>
    <?php if(isset($berita)): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <!-- Main Content -->
    <div class="lg:col-span-2 space-y-6">
        <!-- Judul -->
        <div class="glass-card rounded-2xl p-6">
            <label for="judul" class="block text-sm font-semibold text-gray-700 mb-2">
                Judul <span class="text-red-500">*</span>
            </label>
            <input type="text"
                   id="judul"
                   name="judul"
                   value="<?php echo e(old('judul', $berita->judul ?? '')); ?>"
                   class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   placeholder="Masukkan judul berita yang menarik"
                   required>
            <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Slug -->
        <div class="glass-card rounded-2xl p-6">
            <label for="slug" class="block text-sm font-semibold text-gray-700 mb-2">
                Slug <span class="text-gray-500 text-xs font-normal">(Otomatis dihasilkan)</span>
            </label>
            <input type="text"
                   id="slug"
                   name="slug"
                   value="<?php echo e(old('slug', $berita->slug ?? '')); ?>"
                   class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   placeholder="url-friendly-slug">
            <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Ringkasan -->
        <div class="glass-card rounded-2xl p-6">
            <label for="ringkasan" class="block text-sm font-semibold text-gray-700 mb-2">
                Ringkasan <span class="text-red-500">*</span>
            </label>
            <textarea id="ringkasan"
                      name="ringkasan"
                      rows="3"
                      maxlength="500"
                      class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 <?php $__errorArgs = ['ringkasan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                      placeholder="Tulis ringkasan singkat yang menarik (maksimal 500 karakter)"
                      required><?php echo e(old('ringkasan', $berita->ringkasan ?? '')); ?></textarea>
            <div class="flex justify-between items-center mt-2">
                <?php $__errorArgs = ['ringkasan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-sm text-red-600"><?php echo e($message); ?></p>
                <?php else: ?>
                    <span></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <span id="ringkasan-count" class="text-sm text-gray-500">0/500</span>
            </div>
        </div>

        <!-- Konten -->
        <div class="glass-card rounded-2xl p-6">
            <label for="konten" class="block text-sm font-semibold text-gray-700 mb-2">
                Konten <span class="text-red-500">*</span>
            </label>
            <textarea id="konten"
                      name="konten"
                      rows="15"
                      class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 <?php $__errorArgs = ['konten'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                      placeholder="Tulis konten lengkap berita di sini..."
                      required><?php echo e(old('konten', $berita->konten ?? '')); ?></textarea>
            <?php $__errorArgs = ['konten'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Tags -->
        <div class="glass-card rounded-2xl p-6">
            <label for="tags" class="block text-sm font-semibold text-gray-700 mb-2">
                Tags <span class="text-gray-500 text-xs font-normal">(Pisahkan dengan koma)</span>
            </label>
            <input type="text"
                   id="tags"
                   name="tags"
                   value="<?php echo e(old('tags', isset($berita->tags) ? implode(', ', $berita->tags ?? []) : '')); ?>"
                   class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 <?php $__errorArgs = ['tags'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   placeholder="pembangunan, infrastruktur, desa">
            <?php $__errorArgs = ['tags'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <!-- Sidebar -->
    <div class="lg:col-span-1 space-y-6">
        <!-- Publish Settings -->
        <div class="glass-card rounded-2xl p-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Pengaturan Publikasi</h3>

            <!-- Status -->
            <div class="mb-4">
                <label for="status" class="block text-sm font-semibold text-gray-700 mb-2">
                    Status <span class="text-red-500">*</span>
                </label>
                <select id="status"
                        name="status"
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <option value="draft" <?php echo e(old('status', isset($berita) ? $berita->status : 'draft') === 'draft' ? 'selected' : ''); ?>>Draft</option>
                    <option value="published" <?php echo e(old('status', isset($berita) ? $berita->status : '') === 'published' ? 'selected' : ''); ?>>Published</option>
                    <option value="archived" <?php echo e(old('status', isset($berita) ? $berita->status : '') === 'archived' ? 'selected' : ''); ?>>Archived</option>
                </select>
                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Tanggal Publikasi -->
            <div class="mb-4">
                <label for="tanggal_publikasi" class="block text-sm font-semibold text-gray-700 mb-2">
                    Tanggal Publikasi
                </label>
                <input type="date"
                       id="tanggal_publikasi"
                       name="tanggal_publikasi"
                       value="<?php echo e(old('tanggal_publikasi', isset($berita) && $berita->tanggal_publikasi ? $berita->tanggal_publikasi->format('Y-m-d') : now()->format('Y-m-d'))); ?>"
                       class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent <?php $__errorArgs = ['tanggal_publikasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__errorArgs = ['tanggal_publikasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Tanggal Berakhir (untuk pengumuman) -->
            <div class="mb-4" id="tanggal-berakhir-container" style="display: none;">
                <label for="tanggal_berakhir" class="block text-sm font-semibold text-gray-700 mb-2">
                    Tanggal Berakhir
                </label>
                <input type="date"
                       id="tanggal_berakhir"
                       name="tanggal_berakhir"
                       value="<?php echo e(old('tanggal_berakhir', isset($berita) && $berita->tanggal_berakhir ? $berita->tanggal_berakhir->format('Y-m-d') : '')); ?>"
                       class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent <?php $__errorArgs = ['tanggal_berakhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__errorArgs = ['tanggal_berakhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Featured & Urgent -->
            <div class="space-y-4">
                <div class="flex items-center">
                    <input type="checkbox"
                           id="is_featured"
                           name="is_featured"
                           value="1"
                           <?php echo e(old('is_featured', isset($berita) ? $berita->is_featured : false) ? 'checked' : ''); ?>

                           class="rounded border-gray-300 text-blue-600 focus:ring-blue-500">
                    <label for="is_featured" class="ml-2 text-sm text-gray-700">Jadikan berita utama</label>
                </div>

                <div class="flex items-center">
                    <input type="checkbox"
                           id="is_urgent"
                           name="is_urgent"
                           value="1"
                           <?php echo e(old('is_urgent', isset($berita) ? $berita->is_urgent : false) ? 'checked' : ''); ?>

                           class="rounded border-gray-300 text-red-600 focus:ring-red-500">
                    <label for="is_urgent" class="ml-2 text-sm text-gray-700">Pengumuman penting</label>
                </div>

                
            </div>
        </div>

        <!-- Category & Type -->
        <div class="glass-card rounded-2xl p-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Kategori & Jenis</h3>

            <!-- Jenis -->
            <div class="mb-4">
                <label for="jenis" class="block text-sm font-semibold text-gray-700 mb-2">
                    Jenis <span class="text-red-500">*</span>
                </label>
                <select id="jenis"
                        name="jenis"
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent <?php $__errorArgs = ['jenis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <option value="berita" <?php echo e(old('jenis', isset($berita) ? $berita->jenis : 'berita') === 'berita' ? 'selected' : ''); ?>>Berita</option>
                    <option value="pengumuman" <?php echo e(old('jenis', isset($berita) ? $berita->jenis : '') === 'pengumuman' ? 'selected' : ''); ?>>Pengumuman</option>
                </select>
                <?php $__errorArgs = ['jenis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Kategori -->
            <div>
                <label for="kategori_berita_id" class="block text-sm font-semibold text-gray-700 mb-2">
                    Kategori <span class="text-red-500">*</span>
                </label>
                <select id="kategori_berita_id"
                        name="kategori_berita_id"
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent <?php $__errorArgs = ['kategori_berita_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <option value="">Pilih Kategori</option>
                    <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $nama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('kategori_berita_id', isset($berita) ? $berita->kategori_berita_id : '') == $id ? 'selected' : ''); ?>>
                            <?php echo e($nama); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['kategori_berita_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <!-- Gambar Utama -->
        <div class="glass-card rounded-2xl p-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Gambar Utama</h3>

            <?php if(isset($berita) && $berita->gambar_utama): ?>
                <div class="mb-4">
                    <img src="<?php echo e($berita->getGambarUtamaUrl()); ?>"
                         alt="Current image"
                         class="w-full h-48 object-cover rounded-lg">
                </div>
            <?php endif; ?>

            <input type="file"
                   id="gambar_utama"
                   name="gambar_utama"
                   accept="image/*"
                   class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent <?php $__errorArgs = ['gambar_utama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <p class="text-xs text-gray-500 mt-2">Format: JPG, PNG, GIF. Maksimal 2MB</p>
            <?php $__errorArgs = ['gambar_utama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Author Info -->
        <div class="glass-card rounded-2xl p-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Penulis</h3>

            <div class="mb-4">
                <label for="penulis" class="block text-sm font-semibold text-gray-700 mb-2">
                    Nama Penulis <span class="text-gray-500 text-xs font-normal">(Opsional)</span>
                </label>
                <input type="text"
                       id="penulis"
                       name="penulis"
                       value="<?php echo e(old('penulis', isset($berita) ? $berita->penulis : '')); ?>"
                       class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent <?php $__errorArgs = ['penulis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       placeholder="Kosongkan untuk menggunakan nama akun">
                <?php $__errorArgs = ['penulis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div>
                <label for="sumber" class="block text-sm font-semibold text-gray-700 mb-2">
                    Sumber <span class="text-gray-500 text-xs font-normal">(Opsional)</span>
                </label>
                <input type="text"
                       id="sumber"
                       name="sumber"
                       value="<?php echo e(old('sumber', isset($berita) ? $berita->sumber : '')); ?>"
                       class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent <?php $__errorArgs = ['sumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       placeholder="Sumber berita">
                <?php $__errorArgs = ['sumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <!-- Actions -->
        <div class="glass-card rounded-2xl p-6">
            <div class="space-y-3">
                <button type="submit"
                        class="w-full btn-modern px-6 py-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white font-semibold rounded-xl hover:from-blue-700 hover:to-blue-800 transition-all duration-200 shadow-lg hover:shadow-xl">
                    <?php echo e(isset($berita) ? 'Perbarui' : 'Simpan'); ?> Berita
                </button>

                <a href="<?php echo e(route('admin.berita.index')); ?>"
                   class="w-full inline-flex items-center justify-center px-6 py-3 border border-gray-300 text-gray-700 font-medium rounded-xl hover:bg-gray-50 transition-colors duration-200">
                    Batal
                </a>
            </div>
        </div>
    </div>
</form>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const judulInput = document.getElementById('judul');
    const slugInput = document.getElementById('slug');
    const ringkasanInput = document.getElementById('ringkasan');
    const ringkasanCount = document.getElementById('ringkasan-count');
    const jenisSelect = document.getElementById('jenis');
    const tanggalBerakhirContainer = document.getElementById('tanggal-berakhir-container');

    // Auto generate slug
    judulInput.addEventListener('input', function() {
        if (!slugInput.value || slugInput.dataset.autoGenerated) {
            const slug = this.value.toLowerCase()
                .replace(/[^a-z0-9\s-]/g, '')
                .replace(/\s+/g, '-')
                .replace(/-+/g, '-')
                .trim('-');
            slugInput.value = slug;
            slugInput.dataset.autoGenerated = 'true';
        }
    });

    // Manual slug edit
    slugInput.addEventListener('input', function() {
        if (this.value) {
            slugInput.dataset.autoGenerated = 'false';
        }
    });

    // Character count for ringkasan
    function updateRingkasanCount() {
        const count = ringkasanInput.value.length;
        ringkasanCount.textContent = `${count}/500`;

        if (count > 500) {
            ringkasanCount.classList.add('text-red-500');
            ringkasanCount.classList.remove('text-gray-500');
        } else {
            ringkasanCount.classList.remove('text-red-500');
            ringkasanCount.classList.add('text-gray-500');
        }
    }

    ringkasanInput.addEventListener('input', updateRingkasanCount);
    updateRingkasanCount(); // Initial count

    // Show/hide tanggal berakhir based on jenis
    function toggleTanggalBerakhir() {
        if (jenisSelect.value === 'pengumuman') {
            tanggalBerakhirContainer.style.display = 'block';
        } else {
            tanggalBerakhirContainer.style.display = 'none';
        }
    }

    jenisSelect.addEventListener('change', toggleTanggalBerakhir);
    toggleTanggalBerakhir(); // Initial state

    // Image preview
    const gambarInput = document.getElementById('gambar_utama');
    if (gambarInput) {
        gambarInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    // Remove existing preview if any
                    const existingPreview = document.getElementById('image-preview');
                    if (existingPreview) {
                        existingPreview.remove();
                    }

                    // Create new preview
                    const preview = document.createElement('div');
                    preview.id = 'image-preview';
                    preview.className = 'mb-4';
                    preview.innerHTML = `
                        <img src="${e.target.result}"
                             alt="Preview"
                             class="w-full h-48 object-cover rounded-lg">
                        <p class="text-xs text-gray-500 mt-2">Preview gambar baru</p>
                    `;

                    gambarInput.parentNode.insertBefore(preview, gambarInput);
                };
                reader.readAsDataURL(file);
            }
        });
    }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/viper/Music/desa-tanjung-selamat/resources/views/admin/berita/form.blade.php ENDPATH**/ ?>